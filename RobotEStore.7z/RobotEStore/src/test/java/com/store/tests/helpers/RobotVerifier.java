package com.store.tests.helpers;

import com.store.robots.Robot;


public class RobotVerifier {
	private static RobotVerifier robotVerifier = new RobotVerifier();
    static String errorMessage;
	
	private RobotVerifier () {}
	
    static RobotVerifier getRobotVerifier() {
		return robotVerifier;
	}
	
    boolean verifyRobot(Robot robotToBeVerified, Robot expectedRobot) {
    	if(robotToBeVerified.getID() != expectedRobot.getID()) {
    		errorMessage = "The expected ID of the robot is " + expectedRobot.getID() + ", but the received ID of the robot is " + robotToBeVerified.getID() + ".";
            return false;
    	}
    	
    	if(robotToBeVerified.getPrice() != expectedRobot.getPrice()) {
    		errorMessage = "The expected price of the robot with ID" + robotToBeVerified.getID() + " is " + expectedRobot.getPrice() + ", but the received price of the robot is " + robotToBeVerified.getPrice() + ".";
            return false;
    	}
    	

    	if(!robotToBeVerified.getName().equals(expectedRobot.getName())) {
    		errorMessage = "The expected name of the robot with ID " + robotToBeVerified.getID() + " is " + expectedRobot.getName() + ", but the received name of the robot is " + robotToBeVerified.getName() + ".";
            return false;
    	}
    	

    	if(!robotToBeVerified.getDescription().equals(expectedRobot.getDescription())) {
    		errorMessage = "The expected description of the robot with ID  " + robotToBeVerified.getID() + " is " + expectedRobot.getDescription() + ", but the received description of the robot is " + robotToBeVerified.getID() + ".";
            return false;
    	}
    	
    	
    	return true;
    }
	

}

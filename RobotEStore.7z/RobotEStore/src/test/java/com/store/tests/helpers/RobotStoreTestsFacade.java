package com.store.tests.helpers;

import java.util.Iterator;
import java.util.List;

import com.store.robots.Robot;


public class RobotStoreTestsFacade {
	private static RobotStoreTestsFacade robotStoreTestsFacade = new RobotStoreTestsFacade();
	RobotBuilder robotBuilder = RobotBuilder.getRobotBuilder();
	RobotVerifier robotVerifier = RobotVerifier.getRobotVerifier();
	public static String errorMessage;
	static List<Robot> currentRobots;
	
	private RobotStoreTestsFacade() {}
	
    public static RobotStoreTestsFacade getRobotStoreTestsFacade() {
		return robotStoreTestsFacade;
	}
	
    
    public Robot createRobot() {
		return robotBuilder.createRobot();
	}
	
    
    public List<Robot> createRobots(int numberOfRobots) {
		currentRobots = robotBuilder.createRobots(numberOfRobots);
		return currentRobots;
	}
	
    
    public boolean verifyRobotsList(List<Robot> robotsInDatabase) {
		Iterator<Robot> currentRobotsIterator = currentRobots.iterator();
		
		for(Robot robot : robotsInDatabase) {
			boolean robotCorrect = robotVerifier.verifyRobot(robot, currentRobotsIterator.next());
			
			if(!robotCorrect) {
				errorMessage = RobotVerifier.errorMessage;
				return false;
			}
		}
		
		return true;
	}

}

package com.store.tests.helpers;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import com.store.robots.Robot;


public class RobotBuilder {
	private static RobotBuilder robotBuilder = new RobotBuilder();
	private static Random randomDataGenerator = new Random();
	private static final String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnoprstquvxyz";
	static String errorMessage;
	
	private RobotBuilder() {}
	
	public static RobotBuilder getRobotBuilder() {
		return robotBuilder;
	}
	
	Robot createRobot() {
		int robotID = UUID.randomUUID().version();
		float price = randomDataGenerator.nextFloat();
		String name = randomString(20);
		String description = randomString(800);
		
		return new Robot(robotID, price, name, description);
	}
	
	List<Robot> createRobots(int numberOfRobots) {
		ArrayList<Robot> robots = new ArrayList<Robot>();
		
		for(int i = 0; i < numberOfRobots; ++numberOfRobots) {
			robots.add(createRobot());
		}
		
		return robots;
	}
	
	private String randomString(int numberOfCharacters) {
		StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < randomDataGenerator.nextInt(numberOfCharacters); i++) {
        	stringBuilder.append(characters.charAt(randomDataGenerator.nextInt(characters.length())));
        }

        return stringBuilder.toString();
	}

}

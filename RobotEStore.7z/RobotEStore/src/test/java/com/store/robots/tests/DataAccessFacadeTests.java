package com.store.robots.tests;

import org.testng.annotations.Test;

import com.store.robots.DataAccessFacade;
import com.store.robots.DataAccessFacadeInterface;
import com.store.robots.Robot;
import com.store.tests.helpers.RobotStoreTestsFacade;

import org.testng.annotations.BeforeSuite;

import java.util.List;

import org.testng.Assert;
import org.testng.annotations.AfterSuite;


public class DataAccessFacadeTests {
	
	DataAccessFacadeInterface dataAccessFacadeInterface = new DataAccessFacade();
	
	RobotStoreTestsFacade robotStoreTestsFacade = RobotStoreTestsFacade.getRobotStoreTestsFacade();
  
    
	@Test
    public void testAddRobot() {
    	Robot robotToBeAdded = robotStoreTestsFacade.createRobot();
    	
    	boolean robotAdded = dataAccessFacadeInterface.addRobot(robotToBeAdded);
    	
    	Assert.assertTrue(robotAdded, "Robot was not added to database.");
    }
    
    
	@Test
    public void testListRobots() {
    	int numberOfRobots = 456;
    	
    	List<Robot> robots = robotStoreTestsFacade.createRobots(numberOfRobots);
    	
    	for(Robot robot : robots) {
    		dataAccessFacadeInterface.addRobot(robot);
    	}
    	
    	List<Robot> robotsInDatabase = dataAccessFacadeInterface.listRobots(0, numberOfRobots);
    	
    	boolean robotsListIsCorrect = robotStoreTestsFacade.verifyRobotsList(robotsInDatabase);
    	
    	Assert.assertTrue(robotsListIsCorrect, RobotStoreTestsFacade.errorMessage);
    }

    
	@AfterSuite
    public void afterSuite() {
		int numberOfRobots =  dataAccessFacadeInterface.getNumberOfRobots();
		
		List<Robot> robotsInDatabase = dataAccessFacadeInterface.listRobots(0, numberOfRobots);
		
		for(Robot robot : robotsInDatabase) {
    		dataAccessFacadeInterface.deleteRobot(robot.getID());
    	}
    }

}

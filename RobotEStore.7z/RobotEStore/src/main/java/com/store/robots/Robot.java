package com.store.robots;


public class Robot {
	private int ID;
	private float price;
	private String name;
	private String description;
	
	public Robot(int ID, float price, String name, String description) {
		this.ID = ID;
		this.price = price;
		this.name = name;
		this.description = description;
	}

	public int getID() {
		return ID;
	}

	void setID(int iD) {
		ID = iD;
	}

	public float getPrice() {
		return price;
	}

	void setPrice(float price) {
		this.price = price;
	}

	public String getName() {
		return name;
	}

	void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	void setDescription(String description) {
		this.description = description;
	}
	
	

}

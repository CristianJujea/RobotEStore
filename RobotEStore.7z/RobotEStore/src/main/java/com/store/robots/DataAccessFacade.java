package com.store.robots;

import java.util.List;


public class DataAccessFacade implements DataAccessFacadeInterface {

	public Integer getNumberOfRobots() {
		return null;
	}

	public List<Robot> listRobots(int startIndex, int endIndex) {
		return null;
	}

	public Robot getRobot(Integer robotID) {
		return null;
	}

	public boolean addRobot(Robot robotToBeAdded) {
		return false;
	}

	public boolean deleteRobot(Integer robotID) {
		return false;
	}

}

package com.store.robots;

import java.util.*; 


public interface DataAccessFacadeInterface {
	public Integer getNumberOfRobots();
	
    public List<Robot> listRobots(int startIndex, int endIndex);
    
    public Robot getRobot(Integer robotID);
    
    public boolean addRobot(Robot robotToBeAdded);
    
    public boolean deleteRobot(Integer robotID);
    
}
